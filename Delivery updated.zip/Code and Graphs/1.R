# Load necessary libraries
library(readr)
library(dplyr)
library(ggplot2)

# Load the CSV data
airbnb_data <- read_csv("airbnb_data 1.csv")

# Display the structure of the data
str(airbnb_data)

# Display summary statistics of the data
summary(airbnb_data)

# Handle missing values (if any)
# Example: Remove rows with missing values in specific columns
airbnb_data <- airbnb_data %>%
  filter(!is.na(price))

# Conduct exploratory data analysis (EDA)

# Example: Create a histogram of the 'price' variable
price_hist <- ggplot(airbnb_data, aes(x = price)) +
  geom_histogram(binwidth = 50, fill = "skyblue", color = "black") +
  labs(title = "Distribution of Prices",
       x = "Price",
       y = "Frequency") +
  ggtitle("Distribution of Prices")

# Example: Create a scatter plot of 'accommodates' vs 'bedrooms'
scatter_plot <- ggplot(airbnb_data, aes(x = accommodates, y = bedrooms)) +
  geom_point(color = "darkgreen") +
  labs(title = "Scatter Plot of Accommodates vs Bedrooms",
       x = "Accommodates",
       y = "Bedrooms") +
  ggtitle("Scatter Plot of Accommodates vs Bedrooms")

# Example: Create a bar plot of 'room_type' frequencies
room_type_bar <- ggplot(airbnb_data, aes(x = room_type)) +
  geom_bar(fill = "lightblue") +
  labs(title = "Room Type Distribution",
       x = "Room Type",
       y = "Frequency") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  ggtitle("Room Type Distribution")

# Example: Create a boxplot of 'reviews_per_month'
reviews_boxplot <- ggplot(airbnb_data, aes(x = "", y = reviews_per_month)) +
  geom_boxplot(fill = "orange") +
  labs(title = "Distribution of Reviews per Month",
       x = "",
       y = "Reviews per Month") +
  ggtitle("Distribution of Reviews per Month")

# Save the visualizations as image files (optional)

# Save the histogram as a PNG file
ggsave("price_hist.png", plot = price_hist)

# Save the scatter plot as a JPEG file
ggsave("scatter_plot.jpeg", plot = scatter_plot)

# Save the bar plot as a PDF file
ggsave("room_type_bar.pdf", plot = room_type_bar)

# Save the boxplot as a PNG file
ggsave("reviews_boxplot.png", plot = reviews_boxplot)

# Output the cleaned data to a new CSV file (optional)
write_csv(airbnb_data, "cleaned_airbnb_data.csv")
