import numpy as np
import pandas as pd

# Specify the Excel file name (assuming it's in the same directory as your script)
excel_file_name = 'data.xlsx'

# Read the Excel file into a pandas DataFrame
df = pd.read_excel(excel_file_name)

# Extract the first column (index 0)
x_coordinate = list(df.iloc[:, 0])
y_coordinate = list(df.iloc[:,1])


# Now, 'first_column' contains the data from the first column
print(x_coordinate)
print(y_coordinate)



# Step 1: Standardize the data
def standardize_data(data):
    mean = np.mean(data, axis=0)
    std_dev = np.std(data, axis=0)
    standardized_data = (data - mean) / std_dev
    return standardized_data, mean, std_dev

# Step 2: Compute the covariance matrix
def compute_covariance_matrix(data):
    covariance_matrix = np.cov(data, rowvar=False)
    return covariance_matrix

# Step 3: Compute eigenvectors and eigenvalues
def compute_eigenvectors(covariance_matrix):
    eigenvalues, eigenvectors = np.linalg.eig(covariance_matrix)
    # Sort eigenvectors based on eigenvalues in descending order
    sorted_indices = np.argsort(eigenvalues)[::-1]
    eigenvectors = eigenvectors[:, sorted_indices]
    eigenvalues = eigenvalues[sorted_indices]
    return eigenvectors, eigenvalues

# Step 4: Select the top k eigenvectors
def select_top_eigenvectors(eigenvectors, k):
    selected_eigenvectors = eigenvectors[:, :k]
    return selected_eigenvectors

# Step 5: Project the original data onto selected eigenvectors
def project_data(data, selected_eigenvectors):
    projected_data = np.dot(data, selected_eigenvectors)
    return projected_data

# Data
data = np.array([
    x_coordinate,y_coordinate

])

# Number of principal components to keep
k = 75

# Step 1: Standardize the data
standardized_data, mean, std_dev = standardize_data(data)

# Step 2: Compute the covariance matrix
covariance_matrix = compute_covariance_matrix(standardized_data)

# Step 3: Compute eigenvectors and eigenvalues
eigenvectors, eigenvalues = compute_eigenvectors(covariance_matrix)

# Step 4: Select the top k eigenvectors
selected_eigenvectors = select_top_eigenvectors(eigenvectors, k)

# Step 5: Project the original data onto selected eigenvectors
projected_data = project_data(standardized_data, selected_eigenvectors)
projected_data=np.real(projected_data)
print("Original Data:")
# print(data)
print("\nProjected Data (using top", k, "eigenvectors):")
print(projected_data)
print(len(projected_data[0]))

# This code will write the results in the output file.


# Create a DataFrame
df = pd.DataFrame({'Coordinate 1': projected_data[0], 'Coordinate 2': projected_data[1]})

# Specify the Excel file name
excel_file_name = 'output.xlsx'

# Write the DataFrame to an Excel file
df.to_excel(excel_file_name, index=False)

print(f'Data has been written to {excel_file_name}.')
