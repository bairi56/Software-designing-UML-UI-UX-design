from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from time import sleep

# Prompt the user for input
upload_with_images = input("Do you want to upload with images? Reply with Y or N: ").strip().upper() == "Y"

# Configure Chrome options
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--disable-notifications")
driver = webdriver.Chrome(options=chrome_options)

driver.get("https://www.facebook.com")
driver.maximize_window()
sleep(2)

try:
    # Wait for login elements
    email_field = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, 'email')))
    password_field = driver.find_element(By.ID, 'pass')
    login_button = driver.find_element(By.NAME, 'login')

    # Enter login credentials
    email_field.send_keys("mubasharainspedium@gmail.com")
    password_field.send_keys("Inspedium@23")
    login_button.click()
 
    # Wait for the login process to complete
    WebDriverWait(driver, 30).until(EC.url_contains("facebook.com"))

    # Wait for 4 seconds after login (adjust as needed)
    sleep(4)

    # Navigate to the group's page
    driver.get("https://www.facebook.com/groups/774114248153206")
    sleep(4)  # Add a sleep to ensure the page loads before interacting with elements
    driver.execute_script("window.scrollTo(0,200)")
    postbox = driver.find_element(By.XPATH, "//div[@class='x1i10hfl x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x16tdsg8 x1hl2dhg xggy1nq x87ps6o x1lku1pv x1a2a7pz x6s0dn4 xmjcpbm x107yiy2 xv8uw2v x1tfwpuw x2g32xy x78zum5 x1q0g3np x1iyjqo2 x1nhvcw1 x1n2onr6 xt7dq6l x1ba4aug x1y1aw1k xn6708d xwib8y2 x1ye3gou']")
    postbox.click()
    sleep(4)

    # Write your post content
    element = driver.switch_to.active_element
    element.send_keys("this is automated post with image.")
    sleep(6)
    driver.execute_script("window.scrollTo(0,200)")
    # If user chose to upload with images
    if upload_with_images:
        try:
    # Click on the photo/video input icon
            photo_video_icon = driver.find_element(By.XPATH, "//span[text()='Photo/Video']")
            photo_video_icon.click()

            # Wait for the photo/video upload dialog to appear
            WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.XPATH, "//input[@type='file']")))

            # Send the image file path to the input element
            image_upload = driver.find_element(By.XPATH, "//input[@type='file']")
            image_upload.send_keys(r"C:\Users\hp 640\AppData\Local\Programs\Python\Python312\Scripts\Facebook\Images\only ribbon blue.png")

            print("Image uploaded successfully.")

        except Exception as e:
            print("An error occurred while uploading image:", e)


    # Locate and click the post button
    post_button = driver.find_element(By.XPATH, "//div[@aria-label='Post']")
    post_button.click()

    # Wait for the post to be successfully created
    sleep(2)

    print("Post successfully created.")
except Exception as e:
    print("An error occurred:", e)
finally:
    driver.quit()
