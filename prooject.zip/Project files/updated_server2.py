import socket
import threading

# history = []
valid_users = {
    "zubair": "123",
    "faizan": "123",
    "alina": "123",
    "arshad": "123",
    "farhad": "123",
    "daniyal": "123",
    "sajid": "123"
}
all_chattings=[]
logged_in_users = {}
shared_file_name = "coll.txt"
history="document_history.txt"
with open(shared_file_name, "r") as file:
    shared_document = file.read()
    # print(shared_document,"kk")
    # file.write(shared_document + '\n')
    document_versions = [shared_document]
with open(history, "r") as file:
    edit_document_history = file.read()
    history_versions=[edit_document_history]
class Server_Connection:
    def __init__(self):
        self.host = '0.0.0.0'
        self.port = 9999
        self.s = socket.socket()

    def create_socket(self):
        try:
            self.s.bind((self.host, self.port))
            self.s.listen(5)
            print("Server is listening on", (self.host, self.port))
        except socket.error as msg:
            print("Socket Binding error:", str(msg))
    def authenticate_client(self, client_socket):
        global shared_document
        while True:
            client_socket.sendall("Please enter your username:".encode('utf-8'))
            username = client_socket.recv(4096).strip().decode('utf-8').strip()
            client_socket.sendall("Please enter your password:".encode('utf-8'))
            password = client_socket.recv(4096).strip().decode('utf-8').strip()

            if username in valid_users and valid_users[username] == password:
                logged_in_users[client_socket] = username  # Add client_socket to the dictionary
                print("Successfully logged in!", username)
                client_socket.sendall("Done".lower().encode('utf-8'))
                return True
            else:
                print("Invalid credentials. Authentication failed. Username:", username, "Password:", password)
                client_socket.sendall("Failed".encode('utf-8'))

            client_socket.sendall(shared_document.encode('utf-8'))
            client_socket.sendall(edit_document_history.encode('utf-8'))
    def document(self, client_socket):
        global shared_document
        global edit_document_history
        while True:
            data = client_socket.recv(1024).decode()
            username = logged_in_users[client_socket]  
            print("Document is edited by:", username, "edited content:", data)
            updated_data = f"{username} updated: {data}"
            edit_document_history += '\n' + updated_data
            history_versions.append(edit_document_history)
            shared_document += '\n' + data
            document_versions.append(shared_document)
            for c in logged_in_users:
                if c != client_socket:
                    try:
                        c.sendall(shared_document.encode())
                        c.sendall(edit_document_history.encode())
                    except socket.error:
                        logged_in_users.pop(c)
                        break

            # client_socket.sendall(b"Document updated successfully.")
            client_socket.sendall(shared_document.encode())
            client_socket.sendall(edit_document_history.encode())
            with open(shared_file_name, "w") as write_file:
                write_file.write(shared_document)
            with open(history, "w") as history_write_file:
                history_write_file.write(edit_document_history)
    def Chattings(self, client_socket):
        while True:
            chat_msg = client_socket.recv(1024).decode()
            username = logged_in_users[client_socket]  
            print("Message is sent by:", username, "Message is:", chat_msg)
            updated_chat = f"{username} updated: {chat_msg}"
            all_chattings.append(updated_chat)

            for c in logged_in_users:
                if c != client_socket:
                    try:
                        c.sendall(updated_chat.encode())
                    except socket.error:
                        logged_in_users.pop(c)
                        break

            client_socket.sendall(updated_chat)
    def start_server(self):
        while True:
            global client_socket
            client_socket, client_address = self.s.accept()
            print("Connection established with", client_address)
            global authenticated
            authenticated = self.authenticate_client(client_socket)

            if authenticated:
                client_thread = threading.Thread(target=self.document, args=(client_socket,))
                client_thread.start()
                client_thread = threading.Thread(target=self.Chattings, args=(client_socket,))
                client_thread.start()
    def chat_sever(self):
        # authenticated = self.authenticate_client(client_socket)
        if authenticated:
            client_thread = threading.Thread(target=self.Chattings, args=(client_socket,))
            client_thread.start()
c1 = Server_Connection()
c1.create_socket()
c1.start_server()
# c1.chat_sever()
