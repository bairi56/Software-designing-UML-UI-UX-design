import socket
import threading
import customtkinter
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import messagebox
# valid=None
root = None
edit_window=None
text_widget1=None
def show_success_message():
    success_label = customtkinter.CTkLabel(root, text="Authentication successful!", font=('default', 20), bg_color="green")
    success_label.place(x=500, y=400)
    open_next_window()
def permission():
    success_label = customtkinter.CTkLabel(root, text="OK,successful!", font=('default', 20), bg_color="green")
    success_label.place(x=500, y=400)
def open_message_window():
    global text_widget1
    print('A')
    edit_window = customtkinter.CTk()
    edit_window.geometry('800x500')
    edit_window.title('Messages')
    edit_window._set_appearance_mode("black")
    print('B')
    main_frame = customtkinter.CTkFrame(edit_window)
    main_frame.pack(fill="both", expand=True)
    #  Edit Message Label
    edit_msg_label = customtkinter.CTkLabel(
        master=main_frame, text="Edit Message", font=('Arial', 24))
    edit_msg_label.grid(row=0, column=2, columnspan=4, pady=20, sticky="n")
    print('C')
    # Entry for User Message
    user_msg_label = customtkinter.CTkLabel(
        master=main_frame, text="Your Message:", font=('Arial', 20))
    user_msg_label.grid(row=1, column=2, padx=10, pady=10, sticky="w")
    user_msg = customtkinter.CTkEntry(
        master=main_frame, font=('Arial', 25), width=300)
    user_msg.grid(row=2, column=3, padx=10, pady=10, sticky="w")
    print('D')
    # Text Widget for Edit Message
    text_widget1 = tk.Text(main_frame, height=10, width=50)
    # text_widget1.grid(row=2, column=2, columnspan=2, padx=10, pady=10)
    print("here!!!!!")
    # Text Message Button
    text_msg_button = customtkinter.CTkButton(
        master=main_frame,
        text="Send Message",
        command=lambda: cl1.send_chat_message_to(user_msg.get()),
        font=('Arial', 18)
    )
    text_msg_button.grid(row=2, column=2, pady=5, padx=3, sticky="w")
    print("E")
    complete_document = customtkinter.CTkButton(
        master=main_frame,
        text="Updated Chat",
        command=msg_histry_update,
        font=('Arial', 18),
        # bg_color="blue",
        # fg_color="black"
    )
    complete_document.grid(row=3, column=2, pady=5, padx=2, sticky="w")
    edit_window.mainloop()
def open_edit_window():
    global edit_window
    edit_window = customtkinter.CTk()
    edit_window.geometry('800x500')
    edit_window.title('Edit Document')
    edit_window._set_appearance_mode("black")

    main_frame = customtkinter.CTkFrame(edit_window)
    main_frame.pack(fill="both", expand=True)

    # Edit Document Label
    title_label = customtkinter.CTkLabel(master=edit_window, width=150, height=70, text='Collaborative Document Editing System', font=('default', 50), bg_color="white")
    title_label.place(x=300, y=10)

    # Entry for User Edit
    user_edit_label = customtkinter.CTkLabel(
        master=main_frame, text="Enter your edits:", font=('Arial', 22))
    user_edit_label.grid(row=1, column=0, padx=10, pady=10)
    user_edit = customtkinter.CTkEntry(
        master=main_frame, font=('Arial', 24), height=100, width=450)
    user_edit.grid(row=2, column=0, padx=10, pady=10)

    # Edit Button
    edit_button = customtkinter.CTkButton(
        master=main_frame,
        text="Make Edit",
        command=lambda: cl1.make_edit(user_edit.get()),
        font=('Arial', 20),
        # bg_color="green",
        # fg_color="black"
    )
    edit_button.grid(row=3, column=0, pady=20, padx=10, sticky="n")

    # Text Widget for Edit
    # edit_text_label = customtkinter.CTkLabel(
    #     master=main_frame, text="Current Document:", font=('Arial', 14))
    # edit_text_label.grid(row=4, column=0, padx=10, pady=10)

    # Adding a Vertical Scrollbar for Edit Text Widget
    # edit_text_scrollbar = tk.Scrollbar(main_frame, orient="vertical")
    # edit_text_widget = tk.Text(main_frame, height=10, width=50,
    #                            wrap=tk.WORD, yscrollcommand=edit_text_scrollbar.set)
    # edit_text_scrollbar.config(command=edit_text_widget.yview)
    # edit_text_scrollbar.grid(row=5, column=1, sticky="ns")
    # edit_text_widget.grid(row=5, column=0, padx=10, pady=10)

    # Updated Document Button
    complete_document = customtkinter.CTkButton(
        master=main_frame,
        text="Updated Document",
        command=shared_document_update,
        font=('Arial', 20),
        # bg_color="blue",
        # fg_color="black"
    )
    complete_document.grid(row=1, column=1, pady=5, padx=2, sticky="w")

    # Show History Button
    history_button = customtkinter.CTkButton(
        master=main_frame,
        text="Update History",
        command=lambda: cl1.show_history(
            edit_history_widget, threading.Event()),
        font=('Arial', 20),
        # bg_color="blue",
        # fg_color="black"
    )
    # history_button.grid(row=5, column=0, pady=20, padx=10, sticky="s")
    history_button = customtkinter.CTkButton(
        master=main_frame,
        text="Show History",
        command=editing_histry_update,
        font=('Arial', 20),
        # bg_color="blue",
        # fg_color="black"
    )
    history_button.grid(row=1, column=2, pady=5, padx=2, sticky="w")
    # history_button_frame = tk.Frame(history_button)
    # history_button_frame.grid(row=0, column=0)

    # # Create the text_back_button inside history_button_frame
    # text_back_button = customtkinter.CTkButton(
    #     master=history_button_frame,
    #     text="Back",
    #     command=move_back,
    #     font=('Arial', 14)
    # )
    # text_back_button.grid(row=0, column=0, pady=5, padx=3, sticky="w")

    # Text Widget for Edit History
    edit_history_label = customtkinter.CTkLabel(
        master=main_frame, text="History:", font=('Arial', 20))
    # edit_history_label.grid(row=7, column=0, padx=10, pady=10)

    # Adding a Vertical Scrollbar for Edit History Text Widget
    edit_history_scrollbar = tk.Scrollbar(
        main_frame, orient="vertical")
    edit_history_widget = tk.Text(main_frame, height=10, width=50,
                                  wrap=tk.WORD, yscrollcommand=edit_history_scrollbar.set)
    edit_history_scrollbar.config(command=edit_history_widget.yview)
    # edit_history_scrollbar.grid(row=8, column=1, sticky="ns")
    # edit_history_widget.grid(row=8, column=0, padx=10, pady=10)

    # Text Messages Button
    permission_msg_button = customtkinter.CTkButton(main_frame, text="Text Messages", command=lambda: open_message_window(),font=('Arial', 20))
    permission_msg_button.grid(row=1, column=3, pady=6, padx=2, sticky="w")

    # Center the main frame
    main_frame.grid_rowconfigure(0, weight=1)
    main_frame.grid_columnconfigure(0, weight=1)
    main_frame.grid_columnconfigure(1, weight=0)
    edit_window.mainloop()

def open_next_window():
    global edit_window
    edit_window = customtkinter.CTk()
    edit_window.geometry('1000x600')  # Increased window size
    edit_window.title('Document Editor')
    edit_window._set_appearance_mode("dark")
    edit_window.configure(bg='black')

    frame = tk.Frame(edit_window, bg='white')
    frame.place(relx=0.5, rely=0.5, anchor='center')

    def on_hover_in(event):
        event.widget.config(bg="darkblue", fg="white", relief=tk.SUNKEN)

    def on_hover_out(event):
        event.widget.config(bg="blue", fg="yellow", relief=tk.RAISED)

    permission_label = tk.Label(frame, text='Choose Your Option?', font=('Arial', 16), bg='white')
    permission_label.grid(row=0, column=0, columnspan=2, padx=10, pady=20)  # Adjusted columnspan and padding

    permission_button = tk.Button(frame, text="Edit Document", font=('Arial', 14), bg="blue", fg="yellow", command=lambda: handle_permission())
    permission_button.grid(row=1, column=0, padx=10, pady=10)
    permission_button.bind("<Enter>", on_hover_in)
    permission_button.bind("<Leave>", on_hover_out)

    permission_msg_button = tk.Button(frame, text="Conversation", font=('Arial', 14), bg="blue", fg="yellow", command=lambda: handle_msg_permission())
    permission_msg_button.grid(row=1, column=1, padx=20, pady=10)  # Adjusted column position
    permission_msg_button.bind("<Enter>", on_hover_in)
    permission_msg_button.bind("<Leave>", on_hover_out)

    # Adding some additional GUI properties for a nicer look
    frame.grid_columnconfigure(0, weight=1)  # Ensure column 0 expands to fill available space
    frame.grid_columnconfigure(1, weight=1)  # Ensure column 1 expands to fill available space
    frame.grid_rowconfigure(1, weight=1)  # Ensure row 1 expands to fill available space

    edit_window.mainloop()

def open_permission_window():
    global edit_window
    edit_window = customtkinter.CTk()
    edit_window.geometry('500x200')
    edit_window.title('Document Editor')
    edit_window._set_appearance_mode("dark")
    edit_window.configure(bg='black')
    frame = tk.Frame(edit_window, bg='white')
    frame.place(relx=0.5, rely=0.5, anchor='center')
    # permission_msg_entry = tk.Entry(frame, width=50, font=('Arial', 14))
    # permission_msg_entry.grid(row=1, column=0, padx=10, pady=10)
    # permission_msg_button = tk.Button(frame, text="Dooo", font=('Arial', 14),bg="blue",fg="yellow", command=lambda: handle_msg_permission(permission_msg_entry.get()))
    # permission_msg_button.grid(row=2, column=8, padx=20, pady=10)
    edit_window.mainloop()
def handle_permission():
    open_edit_window()
def handle_msg_permission():
        open_message_window()
def show_edits(edit_content):
    global edit_window
    if edit_window:
        edit_text = tk.Text(edit_window, height=40, width=150)
        edit_text.insert(customtkinter.END, edit_content)
        # edit_text.pack()
        print("edit")
        edit_window.mainloop()
def show_msg_edits(edit_content):
    global edit_window
    if edit_window:
        edit_text = tk.Text(edit_window, height=40, width=150)
        edit_text.insert(customtkinter.END, edit_content)
        # edit_text.pack()
        print("edit")
        edit_window.mainloop()
# show_edits("hhhhh")

def authenticate_failed():
    global er_label
    er_label = customtkinter.CTkLabel(root, text="Authentication failed. Please try again!", font=('default', 20), bg_color="green")
    er_label.place(x=500, y=400)
    
    # Destroy the label after 3 seconds
    root.after(3000, lambda: er_label.destroy())
def add_root():
    global root
    root = customtkinter.CTk()
    root.geometry('300x400')
    root._set_appearance_mode("dark")

    # Add your GUI elements here
    img = customtkinter.CTkImage(dark_image=Image.open("cover.jpg"), size=(1600, 800))
    img1 = customtkinter.CTkImage(dark_image=Image.open("lms4.jpg"), size=(400, 400))
    lab = customtkinter.CTkLabel(root, image=img, text="")
    lab1 = customtkinter.CTkLabel(root, image=img1, text="")
    lab.grid(row=0, column=0)
    lab1.place(x=20, y=20)

    title_label = customtkinter.CTkLabel(master=root, width=130, height=50, text='Collaborative Document Editing System', font=('default', 50), bg_color="white")
    title_label.place(x=450, y=10)
    login_label = customtkinter.CTkLabel(master=root, width=120, height=50, text='Login Here', font=('default', 30), bg_color="white")
    login_label.place(x=710, y=90)
    user_name_label = customtkinter.CTkLabel(master=root, width=80, height=30, text='User Name', font=('default', 23), bg_color="yellow")
    user_name_label.place(x=500, y=150)
    user_name_entry = customtkinter.CTkEntry(master=root, height=50, width=500, font=('default', 32))
    # user_name_entry.insert(0, 'Username')
    user_name_entry.place(x=500, y=190)
    password_label = customtkinter.CTkLabel(master=root, width=80, height=30, text='Password', font=('default', 23), bg_color="yellow")
    password_label.place(x=500, y=250)
    password_entry = customtkinter.CTkEntry(master=root, height=50, show='●', width=500, font=('default', 32))
    # password_entry.insert(0, 'Password')
    password_entry.place(x=500, y=290)
    login_button = customtkinter.CTkButton(master=root, text="Login", font=('Arial', 24),command=lambda: cl1.authentication_status(user_name_entry.get(), password_entry.get()))
    login_button.place(x=500, y=355)
    

    root.mainloop()
def move_back():
    open_edit_window()
    print("You are moved Back")
document_update=None
document_update_history=None
Name=None
shared_file_name="doc.txt"
history="doc_histt.txt"
conversation="msgs.txt"
with open(shared_file_name, "r") as file:
    shared_document = file.read()
    # print('\n\n\n\n\n\n\n\n\n\n\n\n',"XXXXXXXXX")
    # print(shared_document,"j")
def shared_document_update():

    global edit_window
    global shared_file_name
    global shared_document
    with open('doc.txt', "r") as file:
        shared_document = file.read()
    print("I have read: ",shared_document)
    # Create a new window to display the updated document
    updated_document_window = customtkinter.CTk()
    updated_document_window.geometry('800x500')
    updated_document_window.title('Updated Document')
    updated_document_window._set_appearance_mode("black")

    updated_document_text_widget = tk.Text(updated_document_window, height=10, width=50,font=22)
    updated_document_text_widget.insert(tk.END, shared_document)
    updated_document_text_widget.pack(padx=10, pady=10)

    # Run the updated document window's main loop
    updated_document_window.mainloop()
with open(history, "r") as file2:
    edit_document_history = file2.read()
def editing_histry_update():
    global edit_window
    global shared_file_name
    global your_conversation_history
    with open('doc_histt.txt', "r") as file2:
        edit_document_history = file2.read()
        # history_versions = [edit_document_history]

    # Create a new window to display the updated document
    updated_document_window = customtkinter.CTk()
    updated_document_window.geometry('800x500')
    updated_document_window.title('Updated Document History')

    updated_document_text_widget = tk.Text(updated_document_window, height=10, width=50,font=22)
    updated_document_text_widget.insert(tk.END, edit_document_history)
    updated_document_text_widget.pack(padx=10, pady=10)

    # Start the main loop for the updated_document_window
    updated_document_window.mainloop()

    # Run the updated document window's main loop
    # updated_document_window.mainloop()
with open(conversation, "r") as file:
    your_conversation_history = file.read()
    conversation_versions=[your_conversation_history]
def msg_histry_update():
    global edit_window
    global shared_file_name
    global your_conversation_history
    with open('msgs.txt', "r") as file:
        your_conversation_history = file.read()
    print("I have read: ",your_conversation_history)

    # Create a new window to display the updated document
    updated_document_window = customtkinter.CTk()
    updated_document_window.geometry('800x500')
    updated_document_window.title('Updated Chat')
    updated_document_window._set_appearance_mode("black")

    updated_document_text_widget = tk.Text(updated_document_window, height=10, width=50,font=22)
    updated_document_text_widget.insert(tk.END, your_conversation_history)
    updated_document_text_widget.pack(padx=10, pady=10)

    # Run the updated document window's main loop
    updated_document_window.mainloop()
class Client:
    valid=None
    username=None
    document_updates=[]
    document_updates_history=[]
    Message_updates=[]
    def __init__(self):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # self.create_menus()
        # self.document_updates=[]
        # self.document_updates_history=[]
        # self.root.mainloop()
        
    def connect_with_server(self):
        server_ip = '127.0.0.1'
        server_port = 9999

        try:
            self.client.connect((server_ip, server_port))
        except socket.error as e:
            print(str(e))
            return
    def authentication_status(self, name, password):
        global Name
        Name=name
        self.name=name
        self.password=password
        self.authenticate_user = False
        global document_update
        global document_update_history
        # while not self.authenticate_user:
        try:
            names = self.client.recv(1024)
            self.client.sendall(self.name.encode('utf-8'))
            passw = self.client.recv(1024)
            self.client.sendall(self.password.encode('utf-8'))
            message_authent_status = self.client.recv(1024).decode('utf-8')
            print(message_authent_status, "msg")
            if message_authent_status.lower() == "Done".lower():
                Client.valid=True
                Client.username =self.name
                print(message_authent_status)
                show_success_message()
                open_next_window()
                self.authenticate_user = True
                # document_update = self.client.recv(4096).decode('utf-8')
                # document_update_history = self.client.recv(4096).decode('utf-8')
                print("Update",document_update,"history",document_update_history)
                # global valid
                
                return self.authenticate_user
            else:
                authenticate_failed()
                print("Authentication failed. Please try again.")

        except Exception as e:
            print("Error sending/receiving data:", str(e))
    def view_updates(self, text_widget, update_flag):
        try:
            # while not update_flag.is_set():  # Continue updating until the flag is set
                document_update = self.client.recv(4096).decode('utf-8')
                # document_update_history = self.client.recv(4096).decode('utf-8')
                print("Received document update:", document_update)
                Client.document_updates.append(document_update)
                # print("Received document update history:_", document_update_history)
                # self.document_updates_history.append(document_update_history)

                # Update the GUI with the accumulated updates
                text_widget.config(state=tk.NORMAL)
                text_widget.delete(1.0, tk.END)  # Clear the current content
                print(Client.document_updates,"doxc")
                for update in shared_document:
                    print("update :",update)
                    text_widget.insert(tk.END, update)
                text_widget.config(state=tk.DISABLED)

                # self.show_notification("Document Updated", f"{Client.username} updated the document.")

        except Exception as e:
            print("Error receiving document updates:", str(e))
    def make_edit(self,user_input):
        print("h")
        text_widget= None
        global shared_document
        global edit_document_history
        self.permission = permission

        if Client.valid:
            print("hello")
            try:
                print("Masla")
                update_flag = threading.Event()  # Flag to signal the update thread to stop
                update_thread = threading.Thread(target=self.view_updates, args=(text_widget, update_flag))
                print("Is thread alive?", update_thread.is_alive())
                update_thread.start()

                while True:
                    # Get the user input for editing
                    # if self.permission.lower() == 'exit':
                    #     # Set the flag to stop the update thread
                    #     update_flag.set()
                    #     break
                    # elif self.permission.lower() == 'yes':  # Checking for 'yes' input
                        try:
                            self.client.sendall(user_input.encode('utf-8'))
                            # with open('doc_histt.txt', "a") as histt_file:
                                # hist_file.write(updated_data)
                            content=f"edit by..:{Name}"+"..."+ f"{user_input}\n"
                            # edit_document_history.write(content + "\n")
                            edit_document_history+='\n'+content
                                # hist_file.flush()  # Flush the buffer
                            print(edit_document_history,"his")
                            print("written=",content + "\n")
                            # with open('doc.txt', "a") as doc_file:
                                # hist_file.write(updated_data)
                            # doc_file.write(user_input + "\n")
                                # hist_file.flush()  # Flush the buffer
                            shared_document += '\n' + user_input
                            print(shared_document,"doc")
                            print("written=",user_input)
                            with open(shared_file_name, "w") as write_file:
                                write_file.write(shared_document)
                            with open(history, "w") as history_write_file:
                                history_write_file.write(edit_document_history)
                            show_edits(user_input)
                        except Exception as e:
                            print("Error sending data:", str(e))
                            break

            except ConnectionResetError:
                print("Connection forcibly closed by the remote host")
            finally:
                self.client.close()
        else:
            print("Please log in first")
    def show_history(self, text_widget, update_flag):
        def update_history():
            try:
                # while not update_flag.is_set():  # Continue updating until the flag is set
                print("hhhhhhh")
                document_update_history = self.client.recv(4096).decode('utf-8')
                print("Received document update history....:", document_update_history)
                Client.document_updates_history.append(document_update_history)

            except Exception as e:
                print("Error receiving document updates:", str(e))

        # Start a separate thread for receiving history updates
        history_thread = threading.Thread(target=update_history)
        history_thread.start()

        # Periodically check for updates in the main thread and update the GUI
        def check_updates():
            # if self.document_updates_history:
            text_widget.config(state=tk.NORMAL)
            text_widget.delete(1.0, tk.END)  # Clear the current content
            print("com his",Client.document_updates_history)
            # for update in edit_document_history:
            #     print("hsitory",update)
            text_widget.insert(tk.END, edit_document_history+'\n')
            text_widget.config(state=tk.DISABLED)

        # Schedule the next update check after 100 milliseconds
        # text_widget.after(100, check_updates)

        # Start the initial update check
        check_updates()
    
    def show_notification(self, title, message):
        messagebox.showinfo(title, message)
    def Check_Messages_updates(self, update_flag):
        global text_widget1
        try:
            # while not update_flag.is_set():  # Continue updating until the flag is set
                Message_update = self.client.recv(4096).decode('utf-8')
                # document_update_history = self.client.recv(4096).decode('utf-8')
                print("Received document update:",Message_update)
                Client.Message_updates.append(Message_update)
                # print("Received document update history:_", document_update_history)
                # self.document_updates_history.append(document_update_history)

                # Update the GUI with the accumulated updates
                text_widget1.config(state=tk.NORMAL)
                text_widget1.delete(1.0, tk.END)  # Clear the current content
                print(Client.Message_updates,"doxc")
                for update in Client.Message_updates:
                    print("update :",update)
                    text_widget1.insert(tk.END, update + '\n')
                text_widget1.config(state=tk.DISABLED)

                # self.show_notification("Message Updated", f"{Client.username} Text a message.")

        except Exception as e:
            print("Error receiving Messages updates:", str(e))
    # def Check_Messages(self):
    #     try:
    #         while True:
    #             Message_update = self.client.recv(4096).decode('utf-8')
    #             print("Received a new message:", Message_update)
    #     except Exception as e:
    #         print("Error receiving Messages:", str(e))
    def send_chat_message_to(self,user_msg):
        global your_conversation_history 
        global text_widget1
        # print("h")
        # print("Message is: ",user_msg)
        # with open('msgs.txt', "a") as msgs_file:
        #     # hist_file.write(updated_data)
        #     content=f"Message by: {Name}"+f"{user_msg}\n"
        #     msgs_file.write(content + "\n")
        #     # hist_file.flush()  # Flush the buffer
        #     print("message written=",content)
        # self.permission = permission

        if Client.valid:
            print("hello")
            try:
                print("Masla")
                update_flag = threading.Event()  # Flag to signal the update thread to stop
                update_thread = threading.Thread(target=self.Check_Messages_updates, args=(update_flag,))
                print("Is thread alive?", update_thread.is_alive())
                update_thread.start()

                while True:
                    # Get the user input for editing
                    # if self.permission.lower() == 'exit':
                    #     # Set the flag to stop the update thread
                    #     update_flag.set()
                    #     break
                    # elif self.permission.lower() == 'yes':  # Checking for 'yes' input
                        try:
                            self.client.sendall(user_msg.encode('utf-8'))
                            msg_content=f"msg by..:{Name}"+" "+ f"{user_msg}\n"
                            # edit_document_history.write(content + "\n")
                            your_conversation_history +='\n'+msg_content
                            with open(conversation, "w") as conversation_history_file:
                                conversation_history_file.write(your_conversation_history)
                            show_msg_edits(user_msg)
                        except Exception as e:
                            print("Error sending data:", str(e))
                            break

            except ConnectionResetError:
                print("Connection forcibly closed by the remote host")
            finally:
                self.client.close()
        else:
            print("Please log in first")

if __name__ == "__main__":
    cl1 = Client()
    gui_thread = threading.Thread(target=add_root)
    gui_thread.start()

    network_thread = threading.Thread(target=cl1.connect_with_server)
    # network_thread = threading.Thread(target=cl1.make_edit)
    network_thread.start()
    # networkk_thread = threading.Thread(target=cl1.make_edit)
    # networkk_thread.start()
    # open_next_window()

