import socket
import threading
import customtkinter
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import messagebox
# valid=None
root = None
edit_window=None
def show_success_message():
    success_label = customtkinter.CTkLabel(root, text="Authentication successful!", font=('default', 20), bg_color="green")
    success_label.place(x=500, y=400)
    open_next_window()
def permission():
    success_label = customtkinter.CTkLabel(root, text="OK,successful!", font=('default', 20), bg_color="green")
    success_label.place(x=500, y=400)
def open_edit_window():
    global edit_window
    edit_window = customtkinter.CTk()
    edit_window.geometry('800x500')
    edit_window.title('Edit Document')
    edit_window._set_appearance_mode("black")
    # title_label = customtkinter.CTkLabel(master=edit_window, width=150, height=70, text='Collaborative Document Editing System', font=('default', 50))
    # title_label.place(x=500, y=10)
    main_frame = customtkinter.CTkFrame(edit_window)
    main_frame.pack(fill="both", expand=True)

    # Edit Document Label
    edit_label = customtkinter.CTkLabel(
        master=main_frame, text="Edit Document", font=('Helvetica', 24, 'bold'), bg_color="lightgrey")
    edit_label.grid(row=0, column=0, columnspan=4, pady=20)

    # Entry for User Edit
    user_edit_label = customtkinter.CTkLabel(
        master=main_frame, text="Enter your edits:", font=('Arial', 14))
    user_edit_label.grid(row=1, column=0, padx=10, pady=10)
    user_edit = customtkinter.CTkEntry(
        master=main_frame, font=('Arial', 14), height=100, width=300)
    user_edit.grid(row=2, column=0, padx=10, pady=10)

    # Edit Button
    edit_button = customtkinter.CTkButton(
        master=main_frame,
        text="Edit",
        command=lambda: cl1.make_edit(perm, user_edit.get(), edit_text_widget),
        font=('Arial', 14),
        bg_color="green",
        fg_color="black"
    )
    edit_button.grid(row=3, column=0, pady=20, padx=10, sticky="n")

    # Text Widget for Edit
    edit_text_label = customtkinter.CTkLabel(
        master=main_frame, text="Current Document:", font=('Arial', 14))
    edit_text_label.grid(row=4, column=0, padx=10, pady=10)

    # Adding a Vertical Scrollbar for Edit Text Widget
    edit_text_scrollbar = tk.Scrollbar(main_frame, orient="vertical")
    edit_text_widget = tk.Text(main_frame, height=10, width=50,
                               wrap=tk.WORD, yscrollcommand=edit_text_scrollbar.set)
    edit_text_scrollbar.config(command=edit_text_widget.yview)
    edit_text_scrollbar.grid(row=5, column=1, sticky="ns")
    edit_text_widget.grid(row=5, column=0, padx=10, pady=10)

    # Show History Button
    history_button = customtkinter.CTkButton(
        master=main_frame,
        text="Show History",
        command=lambda: cl1.show_history(
            edit_history_widget, threading.Event()),
        font=('Arial', 14),
        bg_color="blue",
        fg_color="black"
    )
    history_button.grid(row=6, column=0, pady=20, padx=10, sticky="s")

    # Text Widget for Edit History
    edit_history_label = customtkinter.CTkLabel(
        master=main_frame, text="History:", font=('Arial', 14))
    edit_history_label.grid(row=7, column=0, padx=10, pady=10)

    # Adding a Vertical Scrollbar for Edit History Text Widget
    edit_history_scrollbar = tk.Scrollbar(
        main_frame, orient="vertical")
    edit_history_widget = tk.Text(main_frame, height=10, width=50,
                                  wrap=tk.WORD, yscrollcommand=edit_history_scrollbar.set)
    edit_history_scrollbar.config(command=edit_history_widget.yview)
    edit_history_scrollbar.grid(row=8, column=1, sticky="ns")
    edit_history_widget.grid(row=8, column=0, padx=10, pady=10)

    # Center the main frame
    main_frame.grid_rowconfigure(0, weight=1)
    main_frame.grid_columnconfigure(0, weight=1)
    main_frame.grid_columnconfigure(1, weight=0)

    # Edit Document Label
    # edit_msg_label = customtkinter.CTkLabel(master=frame, text="Edit Message", font=('Arial', 24))
    # edit_msg_label.grid(row=0, column=0, columnspan=4, pady=20)

    # # Entry for User Edit
    # user_msg_label = customtkinter.CTkLabel(master=frame, text="Enter Messages :", font=('Arial', 14))
    # user_msg_label.grid(row=1, column=0, padx=10, pady=10)
    # user_msg = customtkinter.CTkEntry(master=frame, font=('Arial', 14), height=50,width=100)
    # user_msg.grid(row=1, column=1, columnspan=3, padx=10, pady=10)
    # # Edit Button
    # edit_msg_label = customtkinter.CTkLabel(master=frame, text="Current Message Window:", font=('Arial', 14))
    # edit_msg_label.grid(row=2, column=0, padx=10, pady=10)
    # edit_msg_widget = tk.Text(frame, height=10, width=60)
    # edit_msg_widget.grid(row=2, column=1, columnspan=3, padx=10, pady=10)
    # edit_msg_button = customtkinter.CTkButton(
    #     master=frame,
    #     text="Text Message",
    #     command=lambda: cl1.send_chat_message_to(user_msg.get(), edit_msg_widget),
    #     font=('Arial', 14)
    # )
    # edit_msg_button.grid(row=3, column=0, pady=20, padx=10, sticky="w")
    edit_window.mainloop()
def open_next_window():
    global edit_window
    edit_window = customtkinter.CTk()
    edit_window.geometry('500x200')
    edit_window.title('Document Editor')
    edit_window._set_appearance_mode("dark")
    edit_window.configure(bg='black')
    # bg_image = customtkinter.CTkImage(dark_image=Image.open("pee.jpg"), size=(1600, 800))
    # front_pc= customtkinter.CTkLabel(root, image=bg_image, text="")
    # lab1 = customtkinter.CTkLabel(root, image=bg_image, text="")
    # front_pc.grid(row=0, column=0)
    # front_pc.place(x=110, y=110)
    frame = tk.Frame(edit_window, bg='white')
    frame.place(relx=0.5, rely=0.5, anchor='center')

    permission_label = tk.Label(frame, text='Would you like to edit the document?', font=('Arial', 16), bg='white')
    permission_label.grid(row=0, column=0, padx=10, pady=10)

    permission_entry = tk.Entry(frame, width=50, font=('Arial', 14))
    permission_entry.grid(row=1, column=0, padx=10, pady=10)

    permission_button = tk.Button(frame, text="Submit", font=('Arial', 14),bg="blue",fg="yellow", command=lambda: handle_permission(permission_entry.get()))
    permission_button.grid(row=2, column=0, padx=10, pady=10)
    edit_window.mainloop()
def handle_permission(permission):
    if permission.lower() == 'yes':
        global perm
        perm=permission.lower()
        open_edit_window()
    else:
        messagebox.showinfo("User", "User declined editing the document")
        print("User declined editing the document.")

def show_edits(edit_content):
    global edit_window
    if edit_window:
        edit_text = tk.Text(edit_window, height=40, width=150)
        edit_text.insert(customtkinter.END, edit_content)
        edit_text.pack()
        print("edit")
        edit_window.mainloop()
def show_msg_edits(edit_content):
    global edit_window
    if edit_window:
        edit_text = tk.Text(edit_window, height=40, width=150)
        edit_text.insert(customtkinter.END, edit_content)
        edit_text.pack()
        print("edit")
        edit_window.mainloop()
# show_edits("hhhhh")

def authenticate_failed():
    er_label = customtkinter.CTkLabel(root, text="Authentication failed. Please try again!", font=('default', 20), bg_color="green")
    er_label.place(x=500, y=400)
def add_root():
    global root
    root = customtkinter.CTk()
    root.geometry('300x400')
    root._set_appearance_mode("dark")

    # Add your GUI elements here
    img = customtkinter.CTkImage(dark_image=Image.open("cover.jpg"), size=(1600, 800))
    img1 = customtkinter.CTkImage(dark_image=Image.open("lms4.jpg"), size=(400, 400))
    lab = customtkinter.CTkLabel(root, image=img, text="")
    lab1 = customtkinter.CTkLabel(root, image=img1, text="")
    lab.grid(row=0, column=0)
    lab1.place(x=20, y=20)

    title_label = customtkinter.CTkLabel(master=root, width=150, height=70, text='Collaborative Document Editing System', font=('default', 50), bg_color="grey")
    title_label.place(x=500, y=10)
    login_label = customtkinter.CTkLabel(master=root, width=120, height=50, text='Login Here', font=('default', 30), bg_color="blue")
    login_label.place(x=710, y=90)
    user_name_label = customtkinter.CTkLabel(master=root, width=80, height=30, text='User Name', font=('default', 20), bg_color="yellow")
    user_name_label.place(x=500, y=150)
    user_name_entry = customtkinter.CTkEntry(master=root, height=50, width=500, font=('default', 30))
    # user_name_entry.insert(0, 'Username')
    user_name_entry.place(x=500, y=190)
    password_label = customtkinter.CTkLabel(master=root, width=80, height=30, text='Password', font=('default', 20), bg_color="yellow")
    password_label.place(x=500, y=250)
    password_entry = customtkinter.CTkEntry(master=root, height=50, show='●', width=500, font=('default', 30))
    # password_entry.insert(0, 'Password')
    password_entry.place(x=500, y=290)
    login_button = customtkinter.CTkButton(master=root, text="Login", command=lambda: cl1.authentication_status(user_name_entry.get(), password_entry.get()))
    login_button.place(x=500, y=355)
    

    root.mainloop()
document_update=None
document_update_history=None
class Client:
    valid=None
    username=None
    document_updates=[]
    document_updates_history=[]
    Message_updates=[]
    def __init__(self):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # self.create_menus()
        # self.document_updates=[]
        # self.document_updates_history=[]
        # self.root.mainloop()
        
    def connect_with_server(self):
        server_ip = '127.0.0.1'
        server_port = 9999

        try:
            self.client.connect((server_ip, server_port))
        except socket.error as e:
            print(str(e))
            return
    def authentication_status(self, name, password):
        self.name=name
        self.password=password
        self.authenticate_user = False
        global document_update
        global document_update_history
        # while not self.authenticate_user:
        try:
            names = self.client.recv(1024)
            self.client.sendall(self.name.encode('utf-8'))
            passw = self.client.recv(1024)
            self.client.sendall(self.password.encode('utf-8'))
            message_authent_status = self.client.recv(1024).decode('utf-8')
            print(message_authent_status, "msg")
            if message_authent_status.lower() == "Done".lower():
                Client.valid=True
                Client.username =self.name
                print(message_authent_status)
                show_success_message()
                open_next_window()
                self.authenticate_user = True
                # document_update = self.client.recv(4096).decode('utf-8')
                # document_update_history = self.client.recv(4096).decode('utf-8')
                print("Update",document_update,"history",document_update_history)
                # global valid
                
                return self.authenticate_user
            else:
                authenticate_failed()
                print("Authentication failed. Please try again.")

        except Exception as e:
            print("Error sending/receiving data:", str(e))
    def view_updates(self, text_widget, update_flag):
        try:
            # while not update_flag.is_set():  # Continue updating until the flag is set
                document_update = self.client.recv(4096).decode('utf-8')
                # document_update_history = self.client.recv(4096).decode('utf-8')
                print("Received document update:", document_update)
                Client.document_updates.append(document_update)
                # print("Received document update history:_", document_update_history)
                # self.document_updates_history.append(document_update_history)

                # Update the GUI with the accumulated updates
                text_widget.config(state=tk.NORMAL)
                text_widget.delete(1.0, tk.END)  # Clear the current content
                print(Client.document_updates,"doxc")
                for update in Client.document_updates:
                    print("update :",update)
                    text_widget.insert(tk.END, update + '\n')
                text_widget.config(state=tk.DISABLED)

                self.show_notification("Document Updated", f"{Client.username} updated the document.")

        except Exception as e:
            print("Error receiving document updates:", str(e))
    def show_history(self, text_widget, update_flag):
        def update_history():
            try:
                # while not update_flag.is_set():  # Continue updating until the flag is set
                print("hhhhhhh")
                document_update_history = self.client.recv(4096).decode('utf-8')
                print("Received document update history....:", document_update_history)
                Client.document_updates_history.append(document_update_history)

            except Exception as e:
                print("Error receiving document updates:", str(e))

        # Start a separate thread for receiving history updates
        history_thread = threading.Thread(target=update_history)
        history_thread.start()

        # Periodically check for updates in the main thread and update the GUI
        def check_updates():
            # if self.document_updates_history:
            text_widget.config(state=tk.NORMAL)
            text_widget.delete(1.0, tk.END)  # Clear the current content
            print("com his",Client.document_updates_history)
            for update in Client.document_updates_history:
                print("hitory",update)
                text_widget.insert(tk.END, update + '\n')
            text_widget.config(state=tk.DISABLED)

        # Schedule the next update check after 100 milliseconds
        text_widget.after(100, check_updates)

        # Start the initial update check
        check_updates()
    def make_edit(self, permission, user_input, text_widget):
        print("h")
        self.permission = permission

        if Client.valid:
            print("hello")
            try:
                print("Masla")
                update_flag = threading.Event()  # Flag to signal the update thread to stop
                update_thread = threading.Thread(target=self.view_updates, args=(text_widget, update_flag))
                print("Is thread alive?", update_thread.is_alive())
                update_thread.start()

                while True:
                    # Get the user input for editing
                    if self.permission.lower() == 'exit':
                        # Set the flag to stop the update thread
                        update_flag.set()
                        break
                    elif self.permission.lower() == 'yes':  # Checking for 'yes' input
                        try:
                            self.client.sendall(user_input.encode('utf-8'))
                            show_edits(user_input)
                        except Exception as e:
                            print("Error sending data:", str(e))
                            break

            except ConnectionResetError:
                print("Connection forcibly closed by the remote host")
            finally:
                self.client.close()
        else:
            print("Please log in first")
    def show_notification(self, title, message):
        messagebox.showinfo(title, message)
    def Check_Messages_updates(self, text_widget, update_flag):
        try:
            # while not update_flag.is_set():  # Continue updating until the flag is set
                Message_update = self.client.recv(4096).decode('utf-8')
                # document_update_history = self.client.recv(4096).decode('utf-8')
                print("Received document update:",Message_update)
                Client.Message_updates.append(Message_update)
                # print("Received document update history:_", document_update_history)
                # self.document_updates_history.append(document_update_history)

                # Update the GUI with the accumulated updates
                text_widget.config(state=tk.NORMAL)
                text_widget.delete(1.0, tk.END)  # Clear the current content
                print(Client.Message_updates,"doxc")
                for update in Client.Client.Message_updates:
                    print("update :",update)
                    text_widget.insert(tk.END, update + '\n')
                text_widget.config(state=tk.DISABLED)

                self.show_notification("Message Updated", f"{Client.username} Text a message.")

        except Exception as e:
            print("Error receiving Messages updates:", str(e))
    # def Check_Messages(self):
    #     try:
    #         while True:
    #             Message_update = self.client.recv(4096).decode('utf-8')
    #             print("Received a new message:", Message_update)
    #     except Exception as e:
    #         print("Error receiving Messages:", str(e))
    def send_chat_message_to(self,user_msg,text_widget):
        print("h")
        # self.permission = permission

        if Client.valid:
            print("hello")
            try:
                print("Masla")
                update_flag = threading.Event()  # Flag to signal the update thread to stop
                update_thread = threading.Thread(target=self.view_updates, args=(text_widget, update_flag))
                print("Is thread alive?", update_thread.is_alive())
                update_thread.start()

                while True:
                    # Get the user input for editing
                    # if self.permission.lower() == 'exit':
                    #     # Set the flag to stop the update thread
                    #     update_flag.set()
                    #     break
                    # elif self.permission.lower() == 'yes':  # Checking for 'yes' input
                        try:
                            self.client.sendall(user_msg.encode('utf-8'))
                            show_msg_edits(user_msg)
                        except Exception as e:
                            print("Error sending data:", str(e))
                            break

            except ConnectionResetError:
                print("Connection forcibly closed by the remote host")
            finally:
                self.client.close()
        else:
            print("Please log in first")
    # def send_chat_message_to(self,text_widget):
    #     if Client.valid:
    #         try:
    #             update_thread = threading.Thread(target=self.Check_Messages_updates,args=(text_widget,))
    #             update_thread.start()

    #             while True:
    #                 user_msg = input("Enter your message (or 'exit' to quit): ")
    #                 if user_msg.lower() == 'exit':
    #                     break

    #                 try:
    #                     self.client.sendall(user_msg.encode('utf-8'))
    #                 except Exception as e:
    #                     print("Error sending message:", str(e))
    #                     break

    #         except ConnectionResetError:
    #             print("Connection forcibly closed by the remote host")
    #         finally:
    #             # self.client.close()
    #             pass
    #     else:
    #         print("Please log in first to send messages")
if __name__ == "__main__":
    cl1 = Client()
    gui_thread = threading.Thread(target=add_root)
    gui_thread.start()

    network_thread = threading.Thread(target=cl1.connect_with_server)
    # network_thread = threading.Thread(target=cl1.make_edit)
    network_thread.start()
    # networkk_thread = threading.Thread(target=cl1.make_edit)
    # networkk_thread.start()
    # open_next_window()

